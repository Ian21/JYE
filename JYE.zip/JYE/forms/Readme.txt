Fully working PHP/AJAX contact form script.
By ian wadidika 