Thanks for downloading this template!

Name: James Yoka Ekip
URL: yokaekip@gmail.com
Designer: Ian K Wadidika 
Technical: ianmcshane8@gmail.com
